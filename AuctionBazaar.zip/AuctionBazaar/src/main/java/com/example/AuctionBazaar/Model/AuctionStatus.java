package com.example.AuctionBazaar.Model;

//package com.example.auctionbazaar.model;

public enum AuctionStatus {
    CREATED,
    APPROVED,
    ACTIVE,
    COMPLETED,
    CANCELLED
}
