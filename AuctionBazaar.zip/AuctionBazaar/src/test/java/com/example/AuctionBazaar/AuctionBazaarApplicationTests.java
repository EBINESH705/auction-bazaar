package com.example.AuctionBazaar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionBazaarApplicationTests {

	@Test
	void contextLoads() {
	}

}
