import React from 'react'

const Auction = () => {
  return (
    <div>Auction</div>
  )
}

export default Auction